import nodemailer from "nodemailer";
import crypto from "crypto";

// In-memory OTP store { key: { otp, expiresAt } }
// For production, use Redis
const otpStore = new Map();

// South Indian states (detected from IP geolocation)
const SOUTH_INDIA_STATES = [
  "Tamil Nadu", "Karnataka", "Kerala", "Andhra Pradesh",
  "Telangana", "Puducherry", "Lakshadweep", "Andaman and Nicobar Islands"
];

export const isSouthIndia = (regionName = "") => {
  return SOUTH_INDIA_STATES.some(state =>
    regionName.toLowerCase().includes(state.toLowerCase())
  );
};

// Generate 6-digit OTP
const generateOTP = () => crypto.randomInt(100000, 999999).toString();

// Email transporter (use Gmail app password or SendGrid)
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,       // your-email@gmail.com
    pass: process.env.EMAIL_APP_PASS,   // Gmail app password (not regular password)
  },
});

// Send email OTP
export const sendEmailOTP = async (email) => {
  const otp = generateOTP();
  const key = `email:${email}`;
  otpStore.set(key, { otp, expiresAt: Date.now() + 5 * 60 * 1000 }); // 5 min

  await transporter.sendMail({
    from: `"YouTube 2.0" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: "Your OTP for YouTube 2.0 Login",
    html: `
      <div style="font-family:sans-serif;max-width:400px;margin:auto;padding:32px;border:1px solid #eee;border-radius:12px">
        <h2 style="color:#065fd4;margin-bottom:8px">Your Login OTP</h2>
        <p style="color:#555;font-size:15px">Use this OTP to log in to YouTube 2.0. It expires in 5 minutes.</p>
        <div style="font-size:36px;font-weight:700;letter-spacing:8px;color:#1a1a1a;margin:24px 0;text-align:center">
          ${otp}
        </div>
        <p style="color:#aaa;font-size:12px">If you didn't request this, ignore this email.</p>
      </div>
    `,
  });

  return { success: true, method: "email" };
};

// Send mobile OTP (via Twilio — install: npm install twilio)
export const sendMobileOTP = async (phone) => {
  const otp = generateOTP();
  const key = `phone:${phone}`;
  otpStore.set(key, { otp, expiresAt: Date.now() + 5 * 60 * 1000 });

  // Twilio integration
  try {
    const twilio = (await import("twilio")).default;
    const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    await client.messages.create({
      body: `Your YouTube 2.0 OTP is: ${otp}. Valid for 5 minutes.`,
      from: process.env.TWILIO_PHONE,
      to: phone.startsWith("+") ? phone : `+91${phone}`,
    });
  } catch (err) {
    // If Twilio not configured, log OTP in dev
    console.warn("[DEV] Mobile OTP:", otp, "for", phone);
  }

  return { success: true, method: "sms" };
};

// Verify OTP (works for both email and phone)
export const verifyOTP = (identifier, inputOtp) => {
  const emailKey = `email:${identifier}`;
  const phoneKey = `phone:${identifier}`;
  const record = otpStore.get(emailKey) || otpStore.get(phoneKey);

  if (!record) return { valid: false, reason: "OTP not found or already used." };
  if (Date.now() > record.expiresAt) {
    otpStore.delete(emailKey);
    otpStore.delete(phoneKey);
    return { valid: false, reason: "OTP expired." };
  }
  if (record.otp !== inputOtp.trim()) {
    return { valid: false, reason: "Incorrect OTP." };
  }

  // Invalidate after use
  otpStore.delete(emailKey);
  otpStore.delete(phoneKey);
  return { valid: true };
};
