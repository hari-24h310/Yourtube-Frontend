# YouTube 2.0 — Complete Integration Setup Guide

## 1. Install Required npm Packages

### Backend (server/)
```bash
cd server
npm install nodemailer twilio socket.io jsonwebtoken
# Already installed: google-translate-api-x razorpay mongoose
```

### Frontend (yourtube/)
```bash
cd yourtube
npm install socket.io-client
# Already installed: axios next react moment
```

---

## 2. Environment Variables

Create `server/.env`:
```
PORT=5000
MONGO_URI=mongodb://localhost:27017/youtube2

# Email OTP (Gmail App Password)
EMAIL_USER=your-email@gmail.com
EMAIL_APP_PASS=xxxx-xxxx-xxxx-xxxx   # Gmail > Settings > App Passwords

# Mobile OTP (Twilio — optional)
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE=+1234567890

# Razorpay (already configured in your project)
RAZORPAY_KEY_ID=rzp_test_1DP5mmOlF5G5ag
RAZORPAY_KEY_SECRET=nxrHwUJd1LVlBDYWAWcqVaXF

# JWT
JWT_SECRET=your_super_secret_jwt_key
```

---

## 3. Update server/index.js

Add these lines to your existing `server/index.js`:

```js
import http from 'http';
import downloadRoutes from './routes/download.js';
import { initVoIP } from './voip/signalingServer.js';

// Existing: app = express()
// Change: app.listen(...) → use http.createServer

app.use('/download', downloadRoutes);

// OTP routes — add to your existing auth routes:
// import { sendOTP, verifyOTPLogin } from './controllers/authOTP.js';
// router.post('/send-otp', sendOTP);
// router.post('/verify-otp', verifyOTPLogin);

// VoIP — wrap express in http server
const server = http.createServer(app);
initVoIP(server);

server.listen(process.env.PORT || 5000, () => {
  console.log('Server running on port', process.env.PORT || 5000);
});
```

---

## 4. Files You Need to Copy to Your Project

| Source File (generated) | Destination in Your Project |
|---|---|
| `frontend/components/Comment.tsx` | `yourtube/src/components/Comment.tsx` (REPLACE) |
| `frontend/components/Comments.tsx` | `yourtube/src/components/Comments.tsx` (REPLACE) |
| `frontend/components/VideoPlayer.tsx` | `yourtube/src/components/VideoPlayer.tsx` (REPLACE) |
| `frontend/hooks/useTheme.ts` | `yourtube/src/hooks/useTheme.ts` (NEW) |
| `frontend/hooks/useWebRTC.ts` | `yourtube/src/hooks/useWebRTC.ts` (NEW) |
| `frontend/pages/downloads/index.tsx` | `yourtube/src/pages/downloads/index.tsx` (NEW) |
| `frontend/pages/login/index.tsx` | `yourtube/src/pages/login/index.tsx` (REPLACE) |
| `frontend/pages/call/[roomId].tsx` | `yourtube/src/pages/call/[roomId].tsx` (NEW) |
| `server/Modals/DownloadLog.js` | `server/Modals/DownloadLog.js` (NEW) |
| `server/controllers/download.js` | `server/controllers/download.js` (NEW) |
| `server/routes/download.js` | `server/routes/download.js` (NEW) |
| `server/controllers/authOTP.js` | Merge into `server/controllers/auth.js` |
| `server/utils/otpService.js` | `server/utils/otpService.js` (NEW) |
| `server/voip/signalingServer.js` | `server/voip/signalingServer.js` (NEW) |

---

## 5. Apply Theme in _app.tsx

```tsx
// yourtube/src/pages/_app.tsx
import { useTheme } from '../hooks/useTheme';

export default function App({ Component, pageProps }) {
  const theme = useTheme(); // auto-applies to document
  return <Component {...pageProps} />;
}
```

---

## 6. Add Download Button to Video Watch Page

```tsx
// In your watch/[id].tsx or VideoPage component
const handleDownload = async () => {
  const userId = JSON.parse(localStorage.getItem('user') || '{}')._id;
  try {
    const res = await axios.post('/download/video', { userId, videoId: video._id });
    const a = document.createElement('a');
    a.href = res.data.videoUrl;
    a.download = res.data.videoTitle;
    a.click();
  } catch (err: any) {
    if (err.response?.data?.requiresUpgrade) {
      router.push('/plans');
    }
  }
};

// In JSX:
<button onClick={handleDownload}>⬇ Download</button>
```

---

## 7. Start a Video Call

```tsx
// Generate a room link and share with friends
const roomId = `room_${videoId}_${Date.now()}`;
router.push(`/call/${roomId}`);
```

---

## 8. Feature Status Summary

| Feature | Status | Action Needed |
|---|---|---|
| Comment Like/Dislike | ✅ Ready | Copy Comment.tsx + Comments.tsx |
| Comment Translation | ✅ Ready | Already on backend; frontend wired |
| City Display | ✅ Ready | ipapi.co called in Comments.tsx |
| Special Char Block | ✅ Ready | commentValidator.js + frontend regex |
| Auto-remove at 2 dislikes | ✅ Ready | Backend done; frontend shows blocked state |
| Video Download | ✅ Ready | Copy DownloadLog.js + download controller + page |
| Plan Upgrade + Razorpay | ✅ Already in project | Verify /plans page works |
| Dynamic Theme | ✅ Ready | Copy useTheme.ts + add to _app.tsx |
| OTP Auth | ✅ Ready | Copy authOTP.js + otpService.js + login page |
| Gesture Video Player | ✅ Ready | Copy VideoPlayer.tsx |
| VoIP Video Calls | ✅ Ready | Copy signalingServer.js + useWebRTC.ts + call page |

---

## 9. Test Checklist

### Comments
- [ ] Post comment → see city (📍) next to name
- [ ] Click 👍 → count increases, button grays out
- [ ] Click 👎 twice → comment disappears with blocked message
- [ ] Select language → click Translate → blue box appears
- [ ] Try posting `<script>` → error message shown

### Downloads
- [ ] Free user: download 1 video → succeeds
- [ ] Free user: try 2nd download same day → upgrade prompt
- [ ] Premium user: unlimited downloads
- [ ] Visit /downloads → history shown

### Plans
- [ ] Visit /plans → all 4 plans visible
- [ ] Click Upgrade Bronze → Razorpay modal opens
- [ ] Use test card 4111 1111 1111 1111 → payment success
- [ ] Check email for invoice

### Theme
- [ ] Set system clock to 10:30 AM IST from Tamil Nadu IP → light theme
- [ ] Other time → dark theme

### OTP Login
- [ ] Enter email → receive OTP email
- [ ] Enter phone → receive SMS OTP
- [ ] Wrong OTP → error shown
- [ ] Correct OTP → login succeeds

### Video Player Gestures
- [ ] Double-tap right half → skip forward 10s
- [ ] Double-tap left half → rewind 10s
- [ ] Single-tap center → play/pause
- [ ] Triple-tap center → next video
- [ ] Free plan: watch 5 min → paywall overlay shown

### VoIP
- [ ] Go to /call/test-room → camera permission asked
- [ ] Share link → second user joins → both see each other
- [ ] Click Screen share → screen appears in other user's view
- [ ] Click Record → stop → file downloads as .webm
