// Add these to your existing server/controllers/auth.js
// Also add the routes to server/routes/auth.js:
//   router.post('/send-otp', sendOTP);
//   router.post('/verify-otp', verifyOTPLogin);

import { sendEmailOTP, sendMobileOTP, verifyOTP, isSouthIndia } from "../utils/otpService.js";
import Auth from "../Modals/Auth.js";
import jwt from "jsonwebtoken";

// POST /auth/send-otp
export const sendOTP = async (req, res) => {
  try {
    const { identifier } = req.body;
    if (!identifier) return res.status(400).json({ message: "Email or phone required." });

    const isEmail = identifier.includes("@");

    if (isEmail) {
      // South India check: always send email OTP for email identifiers
      await sendEmailOTP(identifier);
      return res.json({ method: "email", message: "Email OTP sent." });
    } else {
      // Phone: detect region
      let region = "";
      try {
        const ipRes = await fetch(`https://ipapi.co/${req.ip}/json/`);
        const ipData = await ipRes.json();
        region = ipData.region || "";
      } catch { /* ignore */ }

      if (isSouthIndia(region)) {
        // South India with phone — prefer email but send SMS
        await sendMobileOTP(identifier);
        return res.json({ method: "sms", message: "SMS OTP sent." });
      } else {
        await sendMobileOTP(identifier);
        return res.json({ method: "sms", message: "SMS OTP sent." });
      }
    }
  } catch (err) {
    console.error("sendOTP error:", err);
    res.status(500).json({ message: "Failed to send OTP." });
  }
};

// POST /auth/verify-otp
export const verifyOTPLogin = async (req, res) => {
  try {
    const { identifier, otp } = req.body;
    if (!identifier || !otp) return res.status(400).json({ message: "identifier and otp required." });

    const result = verifyOTP(identifier, otp);
    if (!result.valid) return res.status(401).json({ message: result.reason });

    // Find or create user
    const isEmail = identifier.includes("@");
    let user = await Auth.findOne(isEmail ? { email: identifier } : { phone: identifier });

    if (!user) {
      // Auto-create account on first OTP login
      user = await Auth.create(
        isEmail
          ? { email: identifier, username: identifier.split("@")[0] }
          : { phone: identifier, username: `user_${identifier.slice(-4)}` }
      );
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || "secret", { expiresIn: "30d" });

    res.json({
      token,
      user: {
        _id: user._id,
        username: user.username,
        email: user.email,
        city: user.city,
      },
    });
  } catch (err) {
    console.error("verifyOTPLogin error:", err);
    res.status(500).json({ message: "Server error." });
  }
};
