// server/voip/signalingServer.js
// Add to server/index.js:
//   import { initVoIP } from './voip/signalingServer.js';
//   const server = http.createServer(app);
//   initVoIP(server);
//   server.listen(PORT, ...);

import { Server } from "socket.io";

const rooms = new Map(); // roomId -> Set of socketIds

export const initVoIP = (httpServer) => {
  const io = new Server(httpServer, {
    cors: { origin: "*", methods: ["GET", "POST"] },
    path: "/socket.io",
  });

  io.on("connection", (socket) => {
    console.log("[VoIP] Connected:", socket.id);

    // Join a call room
    socket.on("join-room", ({ roomId, userId, username }) => {
      socket.join(roomId);
      if (!rooms.has(roomId)) rooms.set(roomId, new Map());
      rooms.get(roomId).set(socket.id, { userId, username });

      // Tell others in the room someone joined
      socket.to(roomId).emit("user-joined", { socketId: socket.id, userId, username });

      // Send current participants to the new joiner
      const participants = Array.from(rooms.get(roomId).entries())
        .filter(([id]) => id !== socket.id)
        .map(([id, info]) => ({ socketId: id, ...info }));
      socket.emit("existing-participants", participants);

      console.log(`[VoIP] ${username} joined room ${roomId}`);
    });

    // WebRTC offer
    socket.on("offer", ({ to, offer }) => {
      io.to(to).emit("offer", { from: socket.id, offer });
    });

    // WebRTC answer
    socket.on("answer", ({ to, answer }) => {
      io.to(to).emit("answer", { from: socket.id, answer });
    });

    // ICE candidates
    socket.on("ice-candidate", ({ to, candidate }) => {
      io.to(to).emit("ice-candidate", { from: socket.id, candidate });
    });

    // Screen share started
    socket.on("screen-share-start", ({ roomId }) => {
      socket.to(roomId).emit("screen-share-start", { from: socket.id });
    });

    // Screen share stopped
    socket.on("screen-share-stop", ({ roomId }) => {
      socket.to(roomId).emit("screen-share-stop", { from: socket.id });
    });

    // Leave room
    socket.on("leave-room", ({ roomId }) => {
      handleLeave(socket, roomId, io);
    });

    socket.on("disconnect", () => {
      rooms.forEach((participants, roomId) => {
        if (participants.has(socket.id)) {
          handleLeave(socket, roomId, io);
        }
      });
      console.log("[VoIP] Disconnected:", socket.id);
    });
  });

  return io;
};

function handleLeave(socket, roomId, io) {
  socket.leave(roomId);
  const room = rooms.get(roomId);
  if (room) {
    room.delete(socket.id);
    if (room.size === 0) rooms.delete(roomId);
  }
  io.to(roomId).emit("user-left", { socketId: socket.id });
}
