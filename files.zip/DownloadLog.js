import mongoose from "mongoose";

const downloadLogSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Auth",
      required: true,
    },
    videoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Video",
      required: true,
    },
    videoTitle: { type: String, default: "Unknown" },
    videoUrl: { type: String, required: true },
    downloadedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

// Index for fast daily lookup per user
downloadLogSchema.index({ userId: 1, downloadedAt: -1 });

const DownloadLog = mongoose.model("DownloadLog", downloadLogSchema);
export default DownloadLog;
